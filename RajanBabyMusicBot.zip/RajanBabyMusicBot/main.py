from pyrogram import Client, filters
from pytgcalls import PyTgCalls
from pytgcalls import idle
from config import Config

app = Client(
    "RajanBabyMusicBot",
    api_id=Config.API_ID,
    api_hash=Config.API_HASH,
    bot_token=Config.BOT_TOKEN
)

pytg = PyTgCalls(app)

from plugins import *

@app.on_message(filters.command("start"))
async def start_cmd(_, m):
    await m.reply(
        "🌸 𝑅𝑎𝑗𝑎𝑛 𝐵𝑎𝑏𝑦 💗✨\n\n"
        "🎶 Welcome to Rajan Baby Music Bot!\n"
        "💞 Play your favourite songs in VC.\n\n"
        "✨ Commands:\n"
        "/play — Play song\n"
        "/pause — Pause\n"
        "/resume — Resume\n"
        "/stop — Stop\n"
        "/download — Download audio"
    )

app.start()
pytg.start()
idle()