from pyrogram import Client, filters

@Client.on_message(filters.command("hello"))
async def hello(_, m):
    await m.reply("💗 Hello Baby, 𝑅𝑎𝑗𝑎𝑛 𝐵𝑎𝑏𝑦 here! ✨")