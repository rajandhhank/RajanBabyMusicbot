from pyrogram import Client, filters
from pytgcalls import StreamType
from pytgcalls.types.input_stream import AudioPiped, InputStream
import yt_dlp
from main import pytg

@Client.on_message(filters.command("play"))
async def play_cmd(client, m):
    query = " ".join(m.command[1:])
    if not query:
        return await m.reply("💗 Song name likho baby ✨")

    msg = await m.reply("🔍 Searching baby…")

    ydl = yt_dlp.YoutubeDL({"format": "bestaudio"})
    info = ydl.extract_info(f"ytsearch:{query}", download=False)["entries"][0]
    url = info["url"]

    await pytg.join_group_call(
        m.chat.id,
        InputStream(AudioPiped(url)),
        stream_type=StreamType().local_stream
    )

    await msg.edit(f"🎶 Playing **{info['title']}**\n💗 𝑅𝑎𝑗𝑎𝑛 𝐵𝑎𝑏𝑦 ✨")