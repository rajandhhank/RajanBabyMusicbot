from pyrogram import Client, filters
from main import pytg

@Client.on_message(filters.command("pause"))
async def pause(_, m):
    await pytg.pause_stream(m.chat.id)
    await m.reply("⏸ Paused 💗")

@Client.on_message(filters.command("resume"))
async def resume(_, m):
    await pytg.resume_stream(m.chat.id)
    await m.reply("▶️ Resumed 💞")

@Client.on_message(filters.command("stop"))
async def stop(_, m):
    await pytg.leave_group_call(m.chat.id)
    await m.reply("⏹ Stopped 🎶")