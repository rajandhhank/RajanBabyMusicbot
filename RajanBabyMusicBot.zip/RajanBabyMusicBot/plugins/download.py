from pyrogram import Client, filters
import yt_dlp

@Client.on_message(filters.command("download"))
async def dl(_, m):
    query = " ".join(m.command[1:])
    if not query:
        return await m.reply("🎧 Song ka naam batao baby 💗")

    msg = await m.reply("📥 Downloading…")

    ydl = yt_dlp.YoutubeDL({"format": "bestaudio", "outtmpl": "song.mp3"})
    ydl.download([f"ytsearch:{query}"])

    await msg.edit("💗 Done Baby! Sending audio…")
    await m.reply_audio("song.mp3")