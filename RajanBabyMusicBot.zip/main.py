
from pyrogram import Client, filters
from pytgcalls import PyTgCalls
from pytgcalls.types.input_stream import InputStream
from pytgcalls.types.input_stream import AudioPiped
import yt_dlp

API_ID = int(os.getenv("API_ID"))
API_HASH = os.getenv("API_HASH")
BOT_TOKEN = os.getenv("BOT_TOKEN")

app = Client("RajanBabyBot", api_id=API_ID, api_hash=API_HASH, bot_token=BOT_TOKEN)
call = PyTgCalls(app)

@app.on_message(filters.command("start"))
async def start(client, message):
    await message.reply("🎵 **Rajan Baby Music Bot is Online!**
Use /play <song> to start.")

@app.on_message(filters.command("play"))
async def play(client, message):
    if len(message.command) < 2:
        return await message.reply("❗ **Give me a song name!**")
    query = message.text.split(None, 1)[1]

    await message.reply("🔎 Searching your song...")

    ydl_opts = {'format': 'bestaudio', 'quiet': True}
    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
        info = ydl.extract_info(f"ytsearch:{query}", download=False)['entries'][0]
        url = info['url']

    await message.reply(f"🎶 Playing: **{info['title']}**")

    await call.join_group_call(
        message.chat.id,
        InputStream(
            AudioPiped(url)
        )
    )

@app.on_message(filters.command("stop"))
async def stop(client, message):
    await call.leave_group_call(message.chat.id)
    await message.reply("🛑 **Stopped playing.**")

app.start()
call.start()
print("Bot Running…")
app.idle()
